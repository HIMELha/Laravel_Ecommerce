


<?php $__env->startSection('contents'); ?>
<div class="px-2 flex justify-center items-center fixed top-0 bottom-0 right-0 left-0 bg-[rgba(0,0,0,0.2)] ">
    <div class="px-6 py-8 w-[600px] flex flex-col justify-center items-center bg-white rounded-md relative">
        <a href="<?php echo e(route('admin.brands')); ?>"><button class="btn absolute top-3 right-3" id="close"><i class="fa-solid fa-close"></i></button></a>
        <h2 class="text-gray-600 text-[17px]">Update Brands</h2>

        <form  class="w-full flex flex-col justify-center gap-3 mt-5" id="editbrandForm" > 
            <?php echo csrf_field(); ?> 
            <p class="errBtn hidden"></p>
            
            <div class="flex-input">
                <div class="w-full flex flex-col ">
                    <label for="name" class="label">name</label>
                    <input type="text" name="name" id="name" value="<?php echo e($data->name); ?>" placeholder="Enter brand name" class="input">
                </div>
                <div class="w-full flex flex-col ">
                    <label for="slug" class="label">slug</label>
                    <input type="text" name="slug" id="slug" value="<?php echo e($data->slug); ?>" placeholder="Enter slug" class="input" readonly>
                </div>
            </div>
            <div class="flex-input">
                <div class="w-full flex flex-col ">
                    <label for="name" class="label">status</label>
                    <select name="status" id="" class="select">
                        
                        <option value="1" <?php if($data->status == 1): ?> selected <?php endif; ?>>Active</option>
                        <option value="0" <?php if($data->status == 0): ?> selected <?php endif; ?>>Pending</option>
                    </select>
                </div>

            </div>


            <div class="flex items-center gap-2">
                <button type="submit" class="btn w-full">Update</button>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('customJs'); ?>
<script>
    $(document).ready(function() {

        $.ajaxSetup({
            headers: {
                "X-CSRF-TOKEN": $('meta[name="csrf-token"]').attr("content"),
            } 
        });

        $('#editbrandForm').submit(function(e){
            e.preventDefault();
            var data = $(this);

            $('button[type=submit]').prop('disabled', true);

            $.ajax({
                url: '<?php echo e(route("brands.update", $data->id )); ?>',
                type: 'put', 
                data: data.serializeArray(),
                dataType: 'json',
                success: function(response){
                    $('button[type=submit]').prop('disabled', false);

                    if(response['status'] == true ){
                        $('.errBtn').hide();
                        window.location.href = '<?php echo e(route("admin.brands")); ?>';
                    } else {
                        
                        var errors = response['errors']; 
                        if(errors['name']){
                            $('.errBtn').show();
                            $('.errBtn').html(errors['name']);
                        }else{
                            $('.errBtn').hide();
                        }
                        if(errors['slug']){
                            $('.errBtn').show();
                            $('.errBtn').append(errors['slug']);
                        }else{
                            $('.errBtn').hide();
                        }
                    }
                },
                error: function(xhr, status, error) {
                    console.error('An error occurred:', error);
                    console.log(xhr.responseText);
                }
            });

        });
    
        $('#name').change( function() {
            var data = $(this);
            $('button[type=submit]').prop('disabled', true);
            $.ajax({
                url: '<?php echo e(route("getSlug")); ?>',
                type: 'get', 
                data: {title: data.val()} ,
                dataType: 'json',
                success: function(response){
                    $('button[type=submit]').prop('disabled', false);
                    if(response['status'] == true){
                        $('#slug').val(response['slug']);
                    }
                }
            })
        });


    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamppp\htdocs\laravel_ecommerce\resources\views/admin/brands/edit.blade.php ENDPATH**/ ?>