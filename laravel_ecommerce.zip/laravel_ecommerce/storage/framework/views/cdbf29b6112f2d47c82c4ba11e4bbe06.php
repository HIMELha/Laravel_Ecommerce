

<?php $__env->startSection('contents'); ?>
  <?php echo $__env->make('front.layouts.categories', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

 <main class="max-w-[1200px] px-2 flex flex-col mx-auto ">
      
      <div class="flex items-center gap-2 my-4">
         <a href=""><i class="fa-solid fa-house text-red"></i></a> 
         <i class="fa-solid fa-angle-right text-dark"></i>
         <a href="" class="link">Payment status</a> 
      </div>
   
      
      
      <div class="flex flex-col justify-center items-center mx-auto py-8">
      <div>
         <?php if($request->status == 'cancel'): ?>
         <p>You have cancelled your payment, Please go to payments history and try again</p>
         <?php elseif($request->status == 'success'): ?>
         <?php if(isset($res['customerMsisdn'])): ?>
            <h2>Your payment was success</h2>
            <p>Pay from: <?php echo e(($res != '' ) ?  $res['customerMsisdn'] : ''); ?></p>
             <p>Pay amount: <?php echo e(($res != '' ) ?  $res['amount'] : ''); ?></p>
            <p>Pay transaction Id: <?php echo e(($res != '' ) ? $res['trxID'] : ''); ?></p>
         <?php endif; ?>
         <?php else: ?>
         <p>Payment failure or something went wrong</p>
         <?php endif; ?>
      </div>

      <div class="flex flex-col sm:flex-row justify-between items-center gap-2 mt-4">
         <a href="<?php echo e(route('user.payments')); ?>"><button class="btn-hover p-3 mt-2">Payment history</button></a>
         <a href="<?php echo e(route('front.product')); ?>"><button class="headBtn mt-2">Continue shopping</button></a>
      </div>
      </div>

      

 </main>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('customJS'); ?>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamp\htdocs\laravel_ecommerce\resources\views/front/bkash.blade.php ENDPATH**/ ?>