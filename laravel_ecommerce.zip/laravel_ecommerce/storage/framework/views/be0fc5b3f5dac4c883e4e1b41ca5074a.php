<?php if(Session::has('error')): ?>
    <ul class="notifications z-50"></ul>
    <div class="buttons">
        <button class="btn hidden" id="error"></button>
    </div>
<?php endif; ?>

<?php if(Session::has('message')): ?>
    <ul class="notifications z-50"></ul>
    <div class="buttons">
            <button class="btn hidden" id="success"></button>
    </div>
<?php endif; ?>




<?php /**PATH C:\xamp\htdocs\laravel_ecommerce\resources\views/admin/message.blade.php ENDPATH**/ ?>