

<?php $__env->startSection('contents'); ?>
        <div class="max-w-[1200px] px-2 flex  justify-between gap-4 mx-auto ">
        <div id="catNav" class="w-[240px] pt-2 bg-light shadow-md   top-0 bottom-0 left-0  z-50 hidden">
          <ul>
            <li class="text-right m-2">
                <buttton id="catclose" class="btn !w-full  cursor-pointer "><i class="fa-solid fa-close"></i></buttton>
            </li>
            <?php if(getCategories()->isNotEmpty()): ?>
            <?php $__currentLoopData = getCategories(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <li>
              <a href="#">
                <span class="category"><i class="fa-solid fa-<?php echo e($category->name); ?> text-red"></i><?php echo e($category->name); ?></span>
              </a>
            </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
            <li>
              <a href="#"><span class="category border-none"><i class="fa-solid fa-dice-d6 text-red"></i>Find more</span></a>
            </li>
          </ul>
        </div>
        </div>


    <!-- main start -->
    <main class="max-w-[1200px] px-2 flex flex-col mx-auto ">
        <div class="flex items-center gap-2 my-4">
            <a href="<?php echo e(route('front.index')); ?>"><i class="fa-solid fa-house text-red"></i></a> 
            <i class="fa-solid fa-angle-right text-dark"></i>
            <a href="<?php echo e(route('pages.details', $page->name )); ?>" class="text-hover"><?php echo e($page->name); ?></a> 
        </div>
        
        <div class="flex flex-col items-start gap-4 mt-6">
            <h2 class="headerText"><?php echo e($page->name); ?></h2>
            <?php echo $page->description; ?>

        </div>
    </main>
    <!-- main end -->

<?php $__env->stopSection(); ?>


<?php $__env->startSection('customJS'); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamppp\htdocs\laravel_ecommerce\resources\views/front/pages.blade.php ENDPATH**/ ?>